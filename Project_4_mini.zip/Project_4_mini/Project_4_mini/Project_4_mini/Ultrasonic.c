/******************************************************************************
 *
 * Module: ULTRASONIC
 *
 * File Name: ultrasonic.c
 *
 * Description: Source file for the AVR ultrasonic driver
 *
 * Author: zyad Mostafa
 *
 *******************************************************************************/
#include "ultrasonic.h"
#include "common_macros.h"
#include "icu.h"
#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "gpio.h"

static uint8 g_edgeCount = 0;
static uint16 g_timeHigh = 0;
/*
 * Initialize the ICU driver as required.
 * Setup the ICU call back function.
 * Setup the direction for the trigger pin as output pin through the GPIO driver
 */
void Ultrasonic_init(void)
{
	/* Create configuration structure for ICU driver */
	ICU_ConfigType Icu_Config = {F_CPU_8,RAISING};
	/* Initialize ICU driver */
	ICU_init(&Icu_Config);
	/* Set the Call back function pointer in the ICU driver */
    ICU_setCallBack(Ultrasonic_edgeProcessing);
    /*Configure Trigger pin as output*/
    GPIO_setupPinDirection(ULTRA_TRIGGER_PORT,ULTRA_TRIGGER_PIN,PIN_OUTPUT);

}
/*
 * Send the Trigger pulse to the ultrasonic.
 */
void Ultrasonic_Trigger(void)
{
	GPIO_writePin(ULTRA_TRIGGER_PORT, ULTRA_TRIGGER_PIN, 1);
	_delay_us(10);
	GPIO_writePin(ULTRA_TRIGGER_PORT, ULTRA_TRIGGER_PIN, 0);
}
uint16 Ultrasonic_readDistance(void)
{
	uint16 distance;
	Ultrasonic_Trigger();
	while (g_timeHigh == 0);/* Wait for falling edge */
	/* 8MHz Timer freq, sound speed =340 m/s ,Prescaler F_CPU/8*/
	distance =(uint16)g_timeHigh / 58.8;
	return distance +3;
}
/*
 * This is the call back function called by the ICU driver.
 */
void Ultrasonic_edgeProcessing(void)
{
	g_edgeCount++;
		if(g_edgeCount == 1)
		{
			/*
			 * Clear the timer counter register to start measurements from the
			 * first detected rising edge
			 */
			ICU_clearTimerValue();
			ICU_setEdgeDetectionType(FALLING);
		}
		else if(g_edgeCount == 2)
		{
			/* Store the High time value */
			g_timeHigh = ICU_getInputCaptureValue();
			/* Detect rising edge */
			ICU_setEdgeDetectionType(RAISING);
			ICU_deInit();
			g_edgeCount=0;
		}
}
