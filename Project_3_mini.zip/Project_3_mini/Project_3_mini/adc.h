// /******************************************************************************
// *
// * Module: ADC
// *
// * File Name: adc.h
// *
// * Description: header file for the ATmega32 ADC driver
// *
// * Author: zyad mostafa
// *
// *******************************************************************************/

//#ifndef ADC_H_
//#define ADC_H_
//
//#include <stdint.h>
//#include "std_types.h"
//
//
//typedef enum {
//    AREF,
//	AVCC_WITH_CAP_AT_AREF,
//	REVERSED,
//	INTERNAL_VREF
//} ADC_ReferenceVoltage;
//
//typedef enum {
//    ADC_PRESCALER_2 = 1,
//    ADC_PRESCALER_4 = 2,
//    ADC_PRESCALER_8 = 3,
//} ADC_Prescaler;
//
//typedef struct {
//    ADC_ReferenceVoltage ref_volt;
//    ADC_Prescaler prescaler;
//} ADC_ConfigType;
//
//void ADC_init(const ADC_ConfigType *Config_Ptr);
//uint16_t ADC_read(uint8_t channel);
//
//#endif /* ADC_H_ */


#ifndef ADC_H_
#define ADC_H_
#include "std_types.h"

/*******************************************************************************
 * Definitions                                                                 *
 *******************************************************************************/
#define ADC_MAXIMUM_VALUE    1023
#define ADC_REF_VOLT_VALUE   2.56

/*******************************************************************************
 * Functions Prototypes                                                        *
 *******************************************************************************/
typedef enum{
	AREF,
	AVCC_WITH_CAP_AT_AREF,
	REVERSED,
	INTERNAL_VREF

}ADC_ReferenceVolatge;

typedef enum{
	DIV_FAC_2 = 1,
	DIV_FAC_4 = 2,
	DIV_FAC_8 = 3,
	DIV_FAC_16 = 4,
	DIV_FAC_32 = 5,
	DIV_FAC_64 = 6,
	DIV_FAC_128 = 7

}ADC_Prescaler;


typedef struct{
 ADC_ReferenceVolatge ref_volt;
 ADC_Prescaler prescaler;
}ADC_ConfigType;


void ADC_init(const ADC_ConfigType * Config_Ptr);
uint16 ADC_readChannel(uint8 channel_num);


#endif /* ADC_H_ */
