/*
 * main.c
 *
 *  Created on: Feb 25, 2024
 *      Author: zyadm
 */

#include <avr/io.h>
#include "adc.h"
#include "gpio.h"
#include "lcd.h"
#include "lm35_sensor.h"
#include "DC-Motor.h"
#include "PWM.h"

typedef enum
{
	FAN_OFF,FAN_ON
}Fan_State;

int main(void) {

	Fan_State Fan1 = FAN_OFF;
    uint8 temp;
    ADC_ConfigType adc_config = {INTERNAL_VREF, DIV_FAC_8};
    ADC_init(&adc_config);
    LCD_init();
    DcMotor_Init();
    PWM_Timer0_Start(0);
    LCD_clearScreen();
	LCD_moveCursor(1,3);
	LCD_displayString("Temp =    C");
    while (1) {

    	temp = LM35_getTemperature();
        if (temp < 30){
			Fan1 = FAN_OFF;
            DcMotor_Rotate(STOP, 0);}
        else if (temp < 60){
			Fan1 = FAN_ON;
            DcMotor_Rotate(CW, 25);}
        else if (temp < 90){
			Fan1 = FAN_ON;
            DcMotor_Rotate(CW, 50);}
        else if (temp < 120){
			Fan1 = FAN_ON;
            DcMotor_Rotate(CW, 75);}
        else{
			Fan1 = FAN_ON;
            DcMotor_Rotate(CW, 100);}

        if(Fan1 == FAN_OFF)
		{
			LCD_moveCursor(0,3);
			LCD_displayString("FAN is OFF");
		}
		else
		{
			LCD_moveCursor(0,3);
			LCD_displayString("FAN is ON ");
		}

		LCD_moveCursor(1,10);
		if(temp >= 100)
		{
			LCD_intgerToString(temp);
		}
		else
		{
			LCD_intgerToString(temp);
			LCD_displayCharacter(' ');
		}

    }
    return 0;
}

